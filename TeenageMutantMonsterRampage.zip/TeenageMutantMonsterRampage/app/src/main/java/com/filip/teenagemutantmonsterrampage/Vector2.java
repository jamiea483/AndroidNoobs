package com.filip.teenagemutantmonsterrampage;

/**
 * Created by darkf on 2017-10-25.
 */

public class Vector2 {
    public float x;
    public float y;

    public Vector2(float xx, float yy) {
        x = xx;
        y = yy;
    }

}
