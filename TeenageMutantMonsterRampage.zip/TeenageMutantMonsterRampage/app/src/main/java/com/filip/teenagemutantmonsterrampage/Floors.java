package com.filip.teenagemutantmonsterrampage;

/**
 * Created by darkf on 2017-11-02.
 */

public class Floors {
    public static int floorsY[] = {1100,896,682,468,254};
    public static int floorHeight = 214;
    public static int bottomHalfStairsHeight = 107;
    public static int stairsWidth = 107;

    public static int stairsUpStartX[] = {630,60,630,340};
}
